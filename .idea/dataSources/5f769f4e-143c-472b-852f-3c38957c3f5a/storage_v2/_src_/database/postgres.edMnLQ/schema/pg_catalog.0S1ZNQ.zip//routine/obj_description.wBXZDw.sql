create function obj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
select description from pg_catalog.pg_description where objoid = $1 and classoid = (select oid from pg_catalog.pg_class where relname = $2 and relnamespace = 11) and objsubid = 0
$$;

comment on function obj_description(oid, name) is 'get description for object id and catalog name';

alter function obj_description(oid, name) owner to postgres;

